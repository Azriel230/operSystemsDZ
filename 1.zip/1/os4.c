#include "csapp.h"

void sigint_handler(int sig) /* Безопасный обработчик SIGINT */
{
    Sio_puts("Caught SIGINT in safe handler!\n"); /* Безопасный вывод */
    _exit(0); /* Безопасный выход */
}

int main()
{
    printf("Sahovsky(37)\n");
    /* Установить обработчик сигнала SIGINT */
    if (signal(SIGINT, sigint_handler) == SIG_ERR)
        unix_error("signal error");

    pause(); /* Ждать получения сигнала */

    return 0;
}